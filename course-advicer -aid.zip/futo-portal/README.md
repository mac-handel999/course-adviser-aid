# FUTO Public Health Results Portal

A small website + web app for entering, grading, and generating transcripts
for the Department of Public Health's year-by-year results, backed by
Supabase for accounts and storage.

## Structure

```
futo-portal/
├── index.html      Landing page (hero, features, how it works)
├── login.html      Sign in / create account page (Supabase auth)
├── app.html        The results app itself (year sheets + transcript generator)
├── css/
│   ├── base.css      Shared colors, fonts, buttons
│   ├── landing.css   Landing page + auth page styles
│   └── app.css       App shell, tables, transcript styles
├── js/
│   ├── landing.js         Mobile nav + footer year for landing/login
│   ├── supabase-config.js Your project's URL + anon key go here
│   ├── auth.js             Sign-in/sign-up form logic
│   └── app.js              Data model, grading, rendering, Excel export, sync
└── sql/
    └── schema.sql    Run this once in the Supabase SQL editor
```

## Setting up Supabase

1. Create a project at https://supabase.com (free tier is fine).
2. In the SQL Editor, paste and run `sql/schema.sql`. This creates the
   `results` table and the row-level security policies that let any
   signed-in account read and write results (a shared department
   workspace, matching how the old spreadsheet worked).
3. In **Project Settings → API**, copy the **Project URL** and the
   **anon public** key into `js/supabase-config.js`.
4. In **Authentication → Providers**, Email is on by default. While
   testing, you can turn off "Confirm email" under
   **Authentication → Settings** so new accounts don't need an email
   click to activate.

That's it — no server to deploy. `login.html` will create real accounts
and `app.html` will load and save results straight from the browser.

## Running it locally

Because the pages load each other's CSS/JS by relative path, and the
Supabase and SheetJS libraries load from a CDN, serve the folder instead
of double-clicking the files:

```
cd futo-portal
python3 -m http.server 8000
# then visit http://localhost:8000
```

(VS Code's "Live Server" extension or `npx serve` work too.)

## How syncing works

- **Signed in**: every edit to a result row is saved to the `results`
  table a fraction of a second after you stop typing. Deleting a row
  deletes it from the table too. On sign-in, the app loads all rows back
  from Supabase.
- **Guest (not signed in, or `supabase-config.js` not filled in yet)**:
  results stay in memory for that browser tab only. Use "Save data" /
  "Load data" in the app to keep a `.json` backup between sessions.

## Notes / things to revisit

- The RLS policies in `schema.sql` treat every signed-in account as a
  department staff member with full read/write access to all results —
  there's no per-user restriction. If you need finer-grained access
  later (e.g. lecturers only editing their own course), that's a policy
  change plus adding a `course owner` concept, not a rewrite.
- There's no password reset flow on the sign-in page yet — Supabase
  supports it (`supabaseClient.auth.resetPasswordForEmail`), it's just
  not wired into the UI.
